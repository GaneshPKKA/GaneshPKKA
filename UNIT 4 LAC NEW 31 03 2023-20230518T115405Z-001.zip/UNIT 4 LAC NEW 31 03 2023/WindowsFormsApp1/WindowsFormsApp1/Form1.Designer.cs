﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.checkbox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtindividualplyer = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_plyenter = new System.Windows.Forms.Button();
            this.lstPlayerbox = new System.Windows.Forms.ListBox();
            this.txtplayer = new System.Windows.Forms.TextBox();
            this.btnNextPlayer = new System.Windows.Forms.Button();
            this.lstINDIVIDUAL = new System.Windows.Forms.ListBox();
            this.btnIndividual = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(474, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(227, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "SCORING BOARD";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(160, 99);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "TEAM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 141);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(322, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "SELECT YOUR TEAM ";
            // 
            // checkbox1
            // 
            this.checkbox1.AutoSize = true;
            this.checkbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkbox1.Location = new System.Drawing.Point(35, 278);
            this.checkbox1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.checkbox1.Name = "checkbox1";
            this.checkbox1.Size = new System.Drawing.Size(142, 36);
            this.checkbox1.TabIndex = 3;
            this.checkbox1.Text = "TEAM 1";
            this.checkbox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(35, 530);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(142, 36);
            this.checkBox2.TabIndex = 4;
            this.checkBox2.Text = "TEAM 4";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(35, 445);
            this.checkBox3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(142, 36);
            this.checkBox3.TabIndex = 5;
            this.checkBox3.Text = "TEAM 3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(35, 365);
            this.checkBox4.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(142, 36);
            this.checkBox4.TabIndex = 6;
            this.checkBox4.Text = "TEAM 2";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(819, 58);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(180, 32);
            this.label4.TabIndex = 7;
            this.label4.Text = "INDIVIDUAL";
            // 
            // txtindividualplyer
            // 
            this.txtindividualplyer.Location = new System.Drawing.Point(777, 127);
            this.txtindividualplyer.Multiline = true;
            this.txtindividualplyer.Name = "txtindividualplyer";
            this.txtindividualplyer.Size = new System.Drawing.Size(252, 39);
            this.txtindividualplyer.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(820, 99);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Enter your name ";
            // 
            // btn_plyenter
            // 
            this.btn_plyenter.Location = new System.Drawing.Point(238, 559);
            this.btn_plyenter.Name = "btn_plyenter";
            this.btn_plyenter.Size = new System.Drawing.Size(217, 59);
            this.btn_plyenter.TabIndex = 10;
            this.btn_plyenter.Text = "Enter";
            this.btn_plyenter.UseVisualStyleBackColor = true;
            this.btn_plyenter.Click += new System.EventHandler(this.btn_plyenter_Click);
            // 
            // lstPlayerbox
            // 
            this.lstPlayerbox.FormattingEnabled = true;
            this.lstPlayerbox.ItemHeight = 29;
            this.lstPlayerbox.Location = new System.Drawing.Point(268, 172);
            this.lstPlayerbox.Name = "lstPlayerbox";
            this.lstPlayerbox.Size = new System.Drawing.Size(277, 381);
            this.lstPlayerbox.TabIndex = 11;
            this.lstPlayerbox.SelectedIndexChanged += new System.EventHandler(this.lstPlayerbox_SelectedIndexChanged);
            // 
            // txtplayer
            // 
            this.txtplayer.Location = new System.Drawing.Point(12, 176);
            this.txtplayer.Multiline = true;
            this.txtplayer.Name = "txtplayer";
            this.txtplayer.Size = new System.Drawing.Size(252, 39);
            this.txtplayer.TabIndex = 12;
            // 
            // btnNextPlayer
            // 
            this.btnNextPlayer.Location = new System.Drawing.Point(1005, 576);
            this.btnNextPlayer.Name = "btnNextPlayer";
            this.btnNextPlayer.Size = new System.Drawing.Size(172, 56);
            this.btnNextPlayer.TabIndex = 13;
            this.btnNextPlayer.Text = "NEXT";
            this.btnNextPlayer.UseVisualStyleBackColor = true;
            this.btnNextPlayer.Click += new System.EventHandler(this.btnNextPlayer_Click);
            // 
            // lstINDIVIDUAL
            // 
            this.lstINDIVIDUAL.FormattingEnabled = true;
            this.lstINDIVIDUAL.ItemHeight = 29;
            this.lstINDIVIDUAL.Location = new System.Drawing.Point(757, 172);
            this.lstINDIVIDUAL.Name = "lstINDIVIDUAL";
            this.lstINDIVIDUAL.Size = new System.Drawing.Size(341, 323);
            this.lstINDIVIDUAL.TabIndex = 14;
            this.lstINDIVIDUAL.SelectedIndexChanged += new System.EventHandler(this.lstINDIVIDUAL_SelectedIndexChanged);
            // 
            // btnIndividual
            // 
            this.btnIndividual.Location = new System.Drawing.Point(805, 501);
            this.btnIndividual.Name = "btnIndividual";
            this.btnIndividual.Size = new System.Drawing.Size(241, 52);
            this.btnIndividual.TabIndex = 15;
            this.btnIndividual.Text = "ENTER";
            this.btnIndividual.UseVisualStyleBackColor = true;
            this.btnIndividual.Click += new System.EventHandler(this.btnIndividual_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(1189, 644);
            this.Controls.Add(this.btnIndividual);
            this.Controls.Add(this.lstINDIVIDUAL);
            this.Controls.Add(this.btnNextPlayer);
            this.Controls.Add(this.txtplayer);
            this.Controls.Add(this.lstPlayerbox);
            this.Controls.Add(this.btn_plyenter);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtindividualplyer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkbox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form1";
            this.Text = "PLAYER";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkbox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtindividualplyer;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_plyenter;
        private System.Windows.Forms.ListBox lstPlayerbox;
        private System.Windows.Forms.TextBox txtplayer;
        private System.Windows.Forms.Button btnNextPlayer;
        private System.Windows.Forms.ListBox lstINDIVIDUAL;
        private System.Windows.Forms.Button btnIndividual;
    }
}

