﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_plyenter_Click(object sender, EventArgs e)
        {
            {
                File.AppendAllLines("Player.txt", new string[] { txtplayer.Text });
                txtplayer.Text = "";
                MessageBox.Show("New player added");
                ShowData();

            }

            void ShowData()
            {
                lstPlayerbox.Items.Clear();
                foreach (string line in File.ReadLines(@"Player.txt", Encoding.UTF8))
                {
                    // process the line
                    lstPlayerbox.Items.Add(line);
                }
                lstPlayerbox.Show();
            }

        }


        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void lstPlayerbox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnNextPlayer_Click(object sender, EventArgs e)
        {

            score scr = new score();
            scr.Show();
        }

        private void lstINDIVIDUAL_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            }

        private void btnIndividual_Click(object sender, EventArgs e)
        {{
                File.AppendAllLines("individual.txt", new string[] { txtindividualplyer.Text });
                txtindividualplyer.Text = "";
                MessageBox.Show("New player added");
                ShowData();

            }

            void ShowData()
            {
                lstINDIVIDUAL.Items.Clear();
                foreach (string line in File.ReadLines(@"individual.txt", Encoding.UTF8))
                {
                    // process the line
                    lstINDIVIDUAL.Items.Add(line);
                }
                lstINDIVIDUAL.Show();
            }
           
            }
        }
    }
    

